
 var Atmf = angular.module('atmf',['ngSanitize','ui.bootstrap','angularUtils.directives.dirPagination','angular-loading-bar']);


    Atmf.filter('html',function($sce){
        return function(input){
            return $sce.trustAsHtml(input);
        }
    });


    Atmf.filter('orderObjectBy', function() {

        return function(items, field, reverse) {
            
            var filtered = [];
            angular.forEach(items, function(item) {
                filtered.push(item);
            });

            filtered.sort(function (a, b) {
                return (a.charAt(0).toLowerCase() > b.charAt(0).toLowerCase() ? 1 : -1);
            });

            if(reverse) filtered.reverse();
                return filtered;
        };

    });




    Atmf.directive("slider", function() {
        return {
            restrict: 'A',
            scope: {
                start: "=",
                end : "=",
                min : "=",
                max:  "=",
                key : "=",
                onchnage : "&",
                onend : "&",

            },

            link: function(scope, elem, attrs ) {

                jQuery(elem).slider({
                    range: true ,
                    min: parseInt(scope.min),
                    max: parseInt(scope.max),
                    values: [ scope.start , scope.end ],
            
                    slide: function(event, ui) { 
                        scope.$apply(function() {
                            scope.start = ui.values[0];
                            scope.end = ui.values[1];
                            scope.onchnage( scope.key , ui.values[0] , ui.values[1] );
                        });
                    },
                    stop: function( event, ui ) {
                        scope.$apply(function(){
                            scope.onend();    
                        });
                    }
                });
            }
        }
    });



    Atmf.config(['cfpLoadingBarProvider', function( cfpLoadingBarProvider ) {
         cfpLoadingBarProvider.includeSpinner = false;
    }]);




    Atmf.controller('AtmfFrontEnd', ['$scope','$filter','$http', '$location', function( $scope , $filter , $http,$location ){


   // var search_page =  JSON.parse(angular.element('#dso').text());



    var loc_data = $location.search();
    
    var loc_length = Object.keys(loc_data).length;

    if (loc_length > 0) {

        do_url_search(loc_data);
    }



   



    if(  angular.isDefined(search_page) ){      

        $scope.list =  search_page.metadata.list;
        $scope.seachPostType = search_page.metadata.search_post_type;
        $scope.postsPerPage = search_page.metadata.post_per_page;
        $scope.contentLimit = search_page.metadata.contentLimit;
        $scope.sortData = search_page.metadata.sort_meta;
    }

	$scope.formData = {};
	$scope.formMeta = {};

    $scope.addTometa = function(key, start , end){
      
        $scope.formMeta[key] = {
            start : start , 
            end  : end
        }
    }

	if( angular.isObject(search_page.post) ){

		$scope.posts = search_page.post;
        $scope.totalItems = $scope.posts.length;
	}

    function do_url_search(loc_data){

        $scope.filterData = {};
        $scope.filterData.alltaxonomies = {};

        if(loc_data.pickUpDate != undefined){
            $scope.filterData.hireon = loc_data.pickUpDate;           
        }

        if(loc_data.returnDate != undefined){
            $scope.filterData.returnon = loc_data.returnDate;      
        }

        if(loc_data.type != undefined){
            $scope.filterData.alltaxonomies['reservation_type'] = loc_data.type;             
        }      

        if(loc_data.location != undefined){
            $scope.filterData.alltaxonomies[loc_data.locationTax] = loc_data.location;             
        }

        if(loc_data.returnLocation != undefined){
            $scope.filterData.alltaxonomies[loc_data.returnLocationTax] = loc_data.returnLocation;             
        }

        if(loc_data.carType != undefined){
            $scope.filterData.alltaxonomies[loc_data.carTypeTax] = loc_data.carType;             
        }

        if(loc_data.reservationTypeTax != undefined){
            $scope.filterData.alltaxonomies[loc_data.reservationTypeTax] = loc_data.searchTerm;            
        }

        $scope.filterData.post_type = search_page.metadata.search_post_type;
        $scope.filterData.sort_meta = search_page.metadata.sort_meta;

        $scope.loading = true;

        console.log($scope.filterData); 

        $http({

            method: 'POST',
            url: atmf.ajaxurl+'?action=atmf_do_filter_url' ,
            data: jQuery.param({ 'filter': $scope.filterData }),
            headers : { 'Content-Type': 'application/x-www-form-urlencoded' }
            
        }).then(function(e){     
            console.log(loc_data.pickUpDate);      
            $scope.posts = [];
            $scope.posts = e.data;
            $scope.hireon = loc_data.pickUpDate;
            $scope.returnon = loc_data.returnDate;
            $scope.pickupLocation = loc_data.location;
            $scope.returnLocation = loc_data.returnLocation;
            $scope.totalItems = $scope.posts.length;
            $scope.loading = false;
            //$location.url($location.path());
        });


    }



    $scope.save_date = function($event, post_id , hireon , returnon, pickupLocation, returnLocation, permalink){

        console.log(post_id);
        console.log(permalink);
        console.log(hireon);
        console.log(returnon);
        console.log(pickupLocation);
        console.log(returnLocation);


        $scope.saveDate = {}; 

        $scope.saveDate = {
            'arrival_date' : hireon,
            'departure_date' : returnon,
            'post_id' : post_id,
            'pickuplocation' : pickupLocation,
            'returnlocation' : returnLocation
        }


        $http({
            method: 'POST',
            url: atmf.ajaxurl+'?action=atmf_do_save_date' ,
            data: jQuery.param({ 'save_date': $scope.saveDate }),
            headers : { 'Content-Type': 'application/x-www-form-urlencoded' }
        }).then(function(e){
            window.location.href = permalink;
        });
      
        $event.preventDefault();

    }







    function throughItem(item , id ){


        //if( item.parent_taxonomy ){

            angular.forEach( item.alloption , function(option , key){

                if ( $scope.blankarray.indexOf( parseInt(key) ) == -1) {
                    $scope.blankarray.push( parseInt(key) );
                }

            });


        //}


        if( angular.isArray(item.items)){
            throughItem(item.items[0] , parseInt(id) );
        }

 
    }


	$scope.selected_taxonomy = [];

	
	$scope.grabResult = function(scope,model, ngitem){



		if( model == true && scope.key != undefined ) {

            if ( $scope.selected_taxonomy.indexOf( parseInt(scope.key) ) == -1) {
                $scope.selected_taxonomy.push( parseInt(scope.key) );
            }

        }else {

            $scope.blankarray = [];
            var taxonomy_name = [];
            if( angular.isArray(ngitem.items) ){

                taxonomy_name.push(ngitem.taxonomy);
                throughItem( ngitem.items[0] , parseInt(scope.key) );

            }
           $scope.selected_taxonomy.splice( $scope.selected_taxonomy.indexOf(parseInt(scope.key)  ), 1 );

           angular.forEach( $scope.blankarray , function(blank_key) {

               if(jQuery.inArray(blank_key ,$scope.selected_taxonomy) != -1){
                   $scope.selected_taxonomy.splice( $scope.selected_taxonomy.indexOf(parseInt(blank_key)  ), 1 );
               }

               // true / false change in the formdata
               angular.forEach($scope.formData , function(cat,taxonomy){

                    if( jQuery.inArray(taxonomy ,taxonomy_name) != -1 ){

                        angular.forEach(cat,function(category,category_key){

                            if( category_key == blank_key ){

                                cat[category_key] = false;
                            }
                        });
                    }
                });

           });



        }

        $scope.doFilter();

	}



    $scope.grabDate = function(dateData){
        
        console.log(dateData);

        $scope.filterData = {
            'hireon': dateData.starton_date ,
            'returnon' : dateData.returnon_date
        }; 


        $scope.filterData.alltaxonomies = {};
        $scope.filterData.post_type = search_page.metadata.search_post_type;
        $scope.filterData.sort_meta = search_page.metadata.sort_meta;

        $scope.loading = true;

        $http({
            method: 'POST',
            url: atmf.ajaxurl+'?action=atmf_do_filter_url' ,
            data: jQuery.param({ 'filter': $scope.filterData }),
            headers : { 'Content-Type': 'application/x-www-form-urlencoded' }
        }).then(function(e){

            console.log(e);
            $scope.posts = [];
            $scope.posts = e.data;

            $scope.totalItems = $scope.posts.length;
            $scope.loading = false;
        });


    }







    $scope.grabMeta = function(){
       $scope.doFilter();
    }


    $scope.isObject = function(scope){

	   	if(angular.isObject(scope))
	   		return true;
	   	else
	   		return false;
    }


    $scope.filterData = {};


    $scope.doFilter = function(){

    	$scope.filterData.taxonomy = $scope.selected_taxonomy;
    	$scope.filterData.metadata = $scope.formMeta;
    	$scope.filterData.alltaxonomies = $scope.formData;
    	$scope.filterData.post_type = search_page.metadata.search_post_type;
        $scope.filterData.sort_meta = search_page.metadata.sort_meta;

        $scope.loading = true;

        $http({
            method: 'POST',
            url: atmf.ajaxurl+'?action=atmf_do_filter' ,
            data: jQuery.param({ 'filter': $scope.filterData }),
            headers : { 'Content-Type': 'application/x-www-form-urlencoded' }
        }).then(function(e){
            $scope.posts = [];
            $scope.posts = e.data;

            $scope.totalItems = $scope.posts.length;
            $scope.loading = false;
        });
    }

    $scope.doReset = function(){
        location.reload();
    }


    $scope.postView = angular.element("#selectView").val();

}]);

 